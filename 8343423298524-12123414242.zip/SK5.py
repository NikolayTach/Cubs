include __FACE__

main face(0)
print('link:null')
in face('happy';'mad';'sad')

new_load('ssd')
or
MAD_Y1[type @log1]
MAD_Y2[type @log11]
MAD_Y3[type @log21]
MAD_Y4[type @log31]
MAD_Y5[type @log41]
MAD_Y6[type @log51]
MAD_Y7[type @log61]
MAD_Y8[type @log71]
MAD_Y9[type @log81]
MAD_Y10[type @log91]
MAD_Y11[type @log101]
MAD_Y12[type @log111]
MAD_Y13[type @log121] 

is ('link:full') as
main face(1)
do queary_range:2,3,4,5,6,7,8,10 
from s/asd/roor.d
side
\
MAD_Y[type @log1]
range Person2 Animal12
\

