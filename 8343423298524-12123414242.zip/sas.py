import soap
import loading_1

pick 0.as(0)
	asp_function
./n
	cz_select
./n
	same
	./n
		null
	./n
	pair_child(1)
		import panda&cows
	patch formation int B_function as asp_function
	./n
			core all fuction 
			print('^AD^AD^')
			print('^GF^GF^')
			mask KDE_@tools 
		pick 0.as(0)
	asp_function
	./n
	cz_select
./n
	same
	./n
		null
		./n
		pair_child(2)
		
